# Create simple book list#
class Book:
    def __init__(self, title="", author=0.0, pages=0, status=""):
        """Set up book class"""
        self.title = title
        self.author = author
        self.pages = pages
        self.status = status

    def __str__(self):
        return "{}, ${},  priority{} ({})".format(self.title, self.author, self.pages, self.get_status())

    def make_csv(self):
        return "{},{},{},{}".format(self.title, self.author, self.pages, self.status)

    def get_status(self):
        if self.status == 'r':
            return  'required'
        elif self.status == 'c':
            return  'completed'


    def is_completed(self):
        if self.status == 'c':
            return True
        elif self.status == 'r':
            return False


def long_pages( self, pages):
        if pages > 500:
            return True
        else:
            return False
