﻿# CP1404ProgrammingAssessment2
Project Reflection for CP1404 Assignment: Reading List by Liuchenxi

1.	How long did the entire project (assignment 2) take you?
 More than 1 week

2.	What are you most satisfied with?
 I try to do my best on build function

3.	What are you least satisfied with?
 to write KV file

4.	What worked well in your development process?
i think all things not too bad

5.	What about your process could be improved the next time you do a project like this?
I want to have more skilled on how to write code
6.	Describe what resources you used and how you used them.
 I use google to search about how to build the button and i also review the lecture and practical

7.	Describe the main challenges or obstacles you faced and how you overcame them.
 The main challenges for me is not familiar with write code, I need to search online and I also not have enough patience and not too careful. I try my best to overcame there shortage.
